import boto3
import json
import pymongo
from pymongo import MongoClient
from datetime import datetime
def does_exist(client, bucket, key):
    """return the key's size if it exist, else None"""
    response = client.list_objects_v2(Bucket=bucket, Prefix=key)
    if response:
        for obj in response['Contents']:
            if key == obj['Key']:
                return True
    return False

PASSWORD = "7MyHZhmubz9eEBBs"
mongo_url = 'cluster0.l3skp.mongodb.net/myFirstDatabase?retryWrites=true&w=majority'
client = MongoClient(f'mongodb+srv://tdirs:{PASSWORD}@{mongo_url}')
s3 = boto3.client('s3')
s3_resource = boto3.resource('s3')
glue_client = boto3.client('glue')

def lambda_handler(event, context):
    # Retrieve File Information
    #1970-01-01T00:00:00.000Z
    try:
        # Get file
        mybucket = s3_resource.Bucket('tdiminirs')
        for bucket_object in mybucket.objects.filter(Prefix="data/", Delimiter='/'):
            print(bucket_object.key)
            if bucket_object.key == 'data/':
                continue
            timestamp = bucket_object.last_modified.strftime("%Y-%m-%d %H:%M:%S UTC")
            #timestamp = f"{time[:10]} {time[11:19]} UTC"
            data = json.loads(bucket_object.get()['Body'].read())
            print(data)
            collection = client['tdi-course']['tdi-collection']
            memberid = data['member_id']
            contentid = data['id_tags']['content_id']
            activityid = data['id_tags']['activity_id']
            query = {"member_id":data['member_id']}
            f = collection.find_one(query)
            if f is None:
                document = ({ "member_id": memberid, "feeds": [
                    { "content_id": contentid, "activity_id" : activityid, "timestamp": timestamp }]
                    })
                collection.insert_one(document)
            else:
                feed = f['feeds']
                check = collection.find( { "feeds.content_id": contentid, "feeds.activity_id": activityid } )
                if check is None:
                    feed.append({ "content_id": contentid, "activity_id" : activityid, "timestamp": timestamp})
                    collection.update_one(query, {'$set': {"feeds": feed}})
            file = bucket_object
            # Copy object A as object B
            copy_source = {
                'Bucket': 'tdiminirs',
                'Key': bucket_object.key,

            }
            print(bucket_object.key)
            mybucket.copy(copy_source, f"rds/{bucket_object.key[5:]}")
            # Delete the former object A
            file.delete()
        job_name="glueminirs"
        job_key="jobid.json"
        job_bucket="tdiminirs"
        statuses = {"RUNNING","STARTING","STOPPING"}
        #create jobid file to keep track
        if does_exist(s3,job_bucket,job_key) == False:
            job_run_id = glue_client.start_job_run(JobName=job_name)
            jobobject = s3_resource.Object(job_bucket, job_key)
            jobobject.put(
                Body=(bytes(json.dumps(job_run_id).encode('UTF-8')))
            )
        else:
            jobobject = s3_resource.Object(job_bucket,job_key)
            file_content = jobobject.get()['Body'].read().decode('utf-8')
            jobdata = json.loads(file_content)
            status_detail = glue_client.get_job_run(JobName=job_name, RunId = jobdata["JobRunId"])
            status = status_detail.get("JobRun").get("JobRunState")
            print(status)
            if status not in statuses:
                job_run_id = glue_client.start_job_run(JobName=job_name)
                jobobject = s3_resource.Object(job_bucket, job_key)
                jobobject.put(
                    Body=(bytes(json.dumps(job_run_id).encode('UTF-8')))
                )
    except Exception as e:
        print(e)
        raise e
